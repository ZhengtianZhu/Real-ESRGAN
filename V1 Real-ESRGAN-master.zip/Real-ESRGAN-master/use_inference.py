import inference_realesrgan

import os


def use_inference(input_image):
    # there is no judgement whether the picture is too big
    str_='python inference_realesrgan.py -n RealESRGAN_x4plus -i  '+input_image+' -o output_2_14'

    output = os.popen(str_)
    type(output)

    return output.read()

    #inference_realesrgan.main()

    pass